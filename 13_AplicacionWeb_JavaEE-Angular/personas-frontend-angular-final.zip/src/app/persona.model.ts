export class Persona {

  constructor(public idPersona: number, public nombre: string) {}
}
